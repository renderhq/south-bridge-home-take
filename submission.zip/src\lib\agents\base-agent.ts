
// Mock Agent Protocol Implementation
export interface Agent {
    id: string;
    name: string;
}
