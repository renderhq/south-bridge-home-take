"use client"

import { useState } from "react"
import { StatusBar } from "@/components/ui/status-bar"
import { Settings } from "@/components/settings"
import { PromptForm } from "@/components/PromptForm"
import { AgentPanel } from "@/components/AgentPanel"
import { AgentState, ToolCall, FileDiff } from "@/lib/types"
import { simulateAgent } from "@/lib/mock-api"

export default function Page() {
  const [selectedAgentId, setSelectedAgentId] = useState<string>("claude-code")
  const [showSettings, setShowSettings] = useState(false)

  const [agents, setAgents] = useState<AgentState[]>([
    {
      id: "claude-code",
      name: "CLAUDE.CODE",
      status: "IDLE",
      task: "WAITING_FOR_INPUT",
      progress: 0,
      output: "Agent ready. Awaiting instructions...",
      files: [],
      toolCalls: [],
      diffs: [],
      time: "0s",
      tokens: "0"
    },
    {
      id: "gemini-cli",
      name: "GEMINI.CLI",
      status: "IDLE",
      task: "WAITING_FOR_INPUT",
      progress: 0,
      output: "System initialized. Ready.",
      files: [],
      toolCalls: [],
      diffs: [],
      time: "0s",
      tokens: "0"
    },
    {
      id: "codex",
      name: "CODEX",
      status: "IDLE",
      task: "WAITING_FOR_INPUT",
      progress: 0,
      output: "Codex engine standby.",
      files: [],
      toolCalls: [],
      diffs: [],
      time: "0s",
      tokens: "0"
    },
  ])

  const [activeAgentIds, setActiveAgentIds] = useState<string[]>(["claude-code"])

  const handlePromptSubmit = async (prompt: string, files: File[]) => {
    // 1. Reset and Start
    const targets = agents.filter(a => activeAgentIds.includes(a.id));

    // Reset state for target agents
    setAgents(prev => prev.map(a => {
      if (activeAgentIds.includes(a.id)) {
        return {
          ...a,
          status: "THINKING",
          progress: 0,
          output: `> ${prompt}\n\n`,
          toolCalls: [],
          diffs: [],
          tokens: "0",
          time: "0s"
        }
      }
      return a;
    }));

    // 2. Trigger Simulation for each
    targets.forEach(agent => {
      const startTime = Date.now();
      simulateAgent(agent.id, prompt, {
        onStream: (chunk) => {
          setAgents(prev => prev.map(a => a.id === agent.id ? { ...a, output: a.output + chunk } : a));
          // Update time/tokens roughly
          const elapsed = Math.floor((Date.now() - startTime) / 1000);
          setAgents(prev => prev.map(a => a.id === agent.id ? {
            ...a,
            time: `${elapsed}s`,
            tokens: `${Math.floor(a.output.length / 4) + 120}`
          } : a));
        },
        onToolCall: (tool) => {
          setAgents(prev => prev.map(a => a.id === agent.id ? { ...a, toolCalls: [...a.toolCalls, tool] } : a));
        },
        onToolUpdate: (toolId, update) => {
          setAgents(prev => prev.map(a => {
            if (a.id !== agent.id) return a;
            return {
              ...a,
              toolCalls: a.toolCalls.map(t => t.id === toolId ? { ...t, ...update } : t)
            }
          }));
        },
        onDiff: (diff) => {
          setAgents(prev => prev.map(a => a.id === agent.id ? { ...a, diffs: [...a.diffs, diff], files: [...new Set([...a.files, diff.path])] } : a));
        },
        onProgress: (prog) => {
          setAgents(prev => prev.map(a => a.id === agent.id ? { ...a, progress: prog } : a));
        },
        onStatus: (status) => {
          setAgents(prev => prev.map(a => a.id === agent.id ? { ...a, status: status } : a));
        },
        onComplete: () => {
          // ensure finalized
        }
      });
    });
  }

  const toggleAgentSelection = (id: string) => {
    setActiveAgentIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  }

  const activeAgentData = agents.find(a => a.id === selectedAgentId) || agents[0];

  return (
    <div className="min-h-screen bg-background flex flex-col font-mono text-foreground">
      <StatusBar onSettingsClick={() => setShowSettings(true)} />

      <div className="flex flex-1 border-t border-border overflow-hidden">
        {/* Sidebar */}
        <div className="w-64 border-r border-border flex flex-col bg-muted/5 flex-shrink-0">

          <div className="p-2 bg-muted/10 border-b border-border text-[9px] font-bold text-muted-foreground px-4 py-2">
            ACTIVE SESSIONS
          </div>

          {/* Agent List */}
          <div className="flex-1 overflow-y-auto">
            {agents.map((agent) => (
              <div
                key={agent.id}
                onClick={() => setSelectedAgentId(agent.id)}
                className={`w-full text-left p-4 border-b border-border cursor-pointer transition-all hover:bg-muted/10 relative group ${selectedAgentId === agent.id ? "bg-muted/20" : ""
                  }`}
              >
                {/* Active Indicator Strip */}
                {selectedAgentId === agent.id && (
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary" />
                )}

                <div className="flex items-center justify-between mb-1">
                  <span className={`text-xs font-bold tracking-tight ${selectedAgentId === agent.id ? "text-foreground" : "text-muted-foreground group-hover:text-foreground"}`}>
                    {agent.name}
                  </span>
                  <span className={`text-[9px] px-1.5 py-0.5 border rounded-sm ${agent.status === "STREAMING" ? "border-green-500 text-green-500 animate-pulse" :
                    agent.status === "ERROR" ? "border-red-500 text-red-500" :
                      "border-border text-muted-foreground"
                    }`}>
                    {agent.status}
                  </span>
                </div>

                <div className="text-[10px] text-muted-foreground truncate font-mono mb-2 opacity-80">
                  {agent.task}
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden">
                    <div
                      className={`h-full ${agent.status === 'ERROR' ? 'bg-red-500' : 'bg-primary'} transition-all duration-500`}
                      style={{ width: `${agent.progress}%` }}
                    />
                  </div>
                  <span className="text-[9px] text-muted-foreground font-mono">{Math.round(agent.progress)}%</span>
                </div>
              </div>
            ))}
          </div>

          {/* Footer removed to keep simple */}
          <div className="p-3 border-t border-border mt-auto">
            <button className="w-full py-2 bg-background border border-border text-xs font-medium hover:bg-primary hover:text-primary-foreground transition-colors uppercase tracking-wider">
              + Initialise Agent
            </button>
          </div>
        </div>

        {/* Main Console Area */}
        <div className="flex-1 flex flex-col min-w-0 bg-background/50">
          <div className="flex-1 overflow-hidden relative">
            <AgentPanel agent={activeAgentData} />
          </div>

          {/* Semantic Prompt Input - Centered & Clean */}
          <div className="border-t border-border bg-background p-6">
            <div className="max-w-3xl mx-auto w-full">
              <PromptForm onSubmit={handlePromptSubmit} />

              {/* Agent Target Selector */}
              <div className="flex items-center gap-4 mt-3 pl-1">
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Target:</span>
                {agents.map(a => (
                  <label key={a.id} className="flex items-center gap-2 text-xs cursor-pointer hover:text-primary transition-colors select-none">
                    <input
                      type="checkbox"
                      checked={activeAgentIds.includes(a.id)}
                      onChange={() => toggleAgentSelection(a.id)}
                      className="accent-primary rounded-sm w-3 h-3"
                    />
                    <span className={activeAgentIds.includes(a.id) ? "text-foreground font-medium" : "text-muted-foreground"}>{a.name}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {showSettings && <Settings onClose={() => setShowSettings(false)} />}
    </div>
  )
}
