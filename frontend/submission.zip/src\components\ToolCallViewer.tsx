"use client"

import { Play, Check, X, Clock } from "lucide-react"
import { ToolCall } from "@/lib/types"

interface ToolCallViewerProps {
    toolCalls: ToolCall[]
}

export function ToolCallViewer({ toolCalls }: ToolCallViewerProps) {
    if (!toolCalls || toolCalls.length === 0) {
        return (
            <div className="h-full flex items-center justify-center text-muted-foreground text-xs font-mono opacity-50">
                NO TOOL CALLS RECORDED
            </div>
        )
    }

    return (
        <div className="space-y-3 p-4 font-mono">
            {toolCalls.map((call) => (
                <div key={call.id} className="border border-border rounded-sm bg-muted/10 overflow-hidden">
                    <div className="flex items-center justify-between px-3 py-2 border-b border-border/50 bg-muted/20">
                        <div className="flex items-center gap-2">
                            <Play className="w-3 h-3 text-primary" />
                            <span className="text-xs font-bold text-foreground">{call.tool}</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <span className="text-[10px] text-muted-foreground">{call.timestamp}</span>
                            {call.status === "running" && <Clock className="w-3 h-3 text-yellow-500 animate-spin" />}
                            {call.status === "completed" && <Check className="w-3 h-3 text-green-500" />}
                            {call.status === "failed" && <X className="w-3 h-3 text-red-500" />}
                        </div>
                    </div>

                    <div className="p-3 text-xs">
                        <div className="mb-2">
                            <span className="text-[9px] uppercase tracking-wider text-muted-foreground block mb-1">Arguments</span>
                            <pre className="bg-black/40 p-2 rounded text-muted-foreground overflow-x-auto">
                                {JSON.stringify(call.args, null, 2)}
                            </pre>
                        </div>

                        {call.result && (
                            <div>
                                <span className="text-[9px] uppercase tracking-wider text-green-500/70 block mb-1">Result</span>
                                <div className="text-green-400 font-mono">{call.result}</div>
                            </div>
                        )}
                    </div>
                </div>
            ))}
        </div>
    )
}
