"use client"

import { FileDiff } from "@/lib/types"
import { FileCode, Plus, Minus, Hash } from "lucide-react"

interface FileDiffViewerProps {
    diffs: FileDiff[]
}

export function FileDiffViewer({ diffs }: FileDiffViewerProps) {
    if (!diffs || diffs.length === 0) {
        return (
            <div className="h-full flex items-center justify-center text-muted-foreground text-xs font-mono opacity-50">
                NO FILE CHANGES DETECTED
            </div>
        )
    }

    return (
        <div className="font-mono text-xs">
            {diffs.map((diff, index) => (
                <div key={index} className="border-b border-border last:border-b-0">
                    <div className="px-4 py-2 bg-muted/20 flex items-center justify-between border-b border-border/50">
                        <div className="flex items-center gap-2">
                            <FileCode className="w-3 h-3 text-muted-foreground" />
                            <span className="font-medium text-foreground">{diff.path}</span>
                        </div>
                        <div className={`px-2 py-0.5 text-[9px] uppercase border rounded-sm ${diff.type === 'create' ? 'border-green-500 text-green-500' :
                                diff.type === 'delete' ? 'border-red-500 text-red-500' :
                                    'border-blue-500 text-blue-500'
                            }`}>
                            {diff.type}
                        </div>
                    </div>

                    <div className="grid grid-cols-2 divide-x divide-border">
                        {/* Original Side */}
                        <div className="bg-red-950/5">
                            <div className="px-3 py-1 text-[9px] text-red-400 bg-red-950/20 border-b border-red-900/20 flex items-center gap-2">
                                <Minus className="w-2 h-2" /> ORIGINAL
                            </div>
                            <div className="p-3 overflow-x-auto">
                                {diff.original ? diff.original.split('\n').map((line, i) => (
                                    <div key={i} className="flex gap-3 text-red-300/60 leading-relaxed">
                                        <span className="w-4 text-right opacity-30 select-none">{i + 1}</span>
                                        <span className="whitespace-pre">{line}</span>
                                    </div>
                                )) : <span className="text-muted-foreground italic opacity-50">Empty</span>}
                            </div>
                        </div>

                        {/* Modified Side */}
                        <div className="bg-green-950/5">
                            <div className="px-3 py-1 text-[9px] text-green-400 bg-green-950/20 border-b border-green-900/20 flex items-center gap-2">
                                <Plus className="w-2 h-2" /> MODIFIED
                            </div>
                            <div className="p-3 overflow-x-auto">
                                {diff.modified ? diff.modified.split('\n').map((line, i) => (
                                    <div key={i} className="flex gap-3 text-green-300/80 leading-relaxed">
                                        <span className="w-4 text-right opacity-30 select-none">{i + 1}</span>
                                        <span className="whitespace-pre">{line}</span>
                                    </div>
                                )) : <span className="text-muted-foreground italic opacity-50">Deleted</span>}
                            </div>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    )
}
