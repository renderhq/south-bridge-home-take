import { ToolCall, FileDiff } from "./types";

interface SimulationCallbacks {
    onStream: (chunk: string) => void;
    onToolCall: (tool: ToolCall) => void;
    onToolUpdate: (toolId: string, update: Partial<ToolCall>) => void;
    onDiff: (diff: FileDiff) => void;
    onProgress: (progress: number) => void;
    onStatus: (status: any) => void;
    onComplete: () => void;
}

const MOCK_RESPONSES = [
    "Analyzing codebase structure...",
    "Identified entry point at src/index.ts.",
    "Checking authentication middleware patterns...",
    "Found simulated session storage. recommending migration to JWT.",
    "Refactoring auth utilities defined in src/lib/auth.ts...",
    "Updating API route handlers to use new 'requireAuth' wrapper.",
    "Running integration tests to verify security headers...",
    "optimization: reduced bundle size by tree-shaking unused lodash imports.",
    "Finalizing changes and formatting code..."
];

const MOCK_TOOLS = [
    { tool: "fs.read_file", args: { path: "src/auth/config.ts" } },
    { tool: "ast.parse", args: { target: "AuthMiddleware" } },
    { tool: "fs.write_file", args: { path: "src/auth/jwt_service.ts" } },
    { tool: "test.run", args: { suite: "auth_spec" } }
];

const MOCK_DIFFS: FileDiff[] = [
    {
        path: "src/auth/config.ts",
        type: "modify",
        original: "export const SESSION_Strategy = 'memory';",
        modified: "export const SESSION_STRATEGY = 'jwt';\nexport const JWT_SECRET = process.env.JWT_SECRET;"
    },
    {
        path: "src/api/routes.ts",
        type: "modify",
        original: "app.use(sessionMiddleware);",
        modified: "app.use(jwtMiddleware);"
    }
];

export function simulateAgent(agentId: string, prompt: string, cb: SimulationCallbacks) {
    let step = 0;
    let progress = 0;

    cb.onStatus("THINKING");

    // Initial delay
    setTimeout(() => {
        cb.onStatus("STREAMING");

        const interval = setInterval(() => {
            // 1. Stream Text
            if (Math.random() > 0.3) {
                const text = MOCK_RESPONSES[step % MOCK_RESPONSES.length];
                const words = text.split(" ");
                // Stream word by word roughly
                const chunk = " " + words[Math.floor(Math.random() * words.length)];
                cb.onStream(chunk);
            }

            // 2. Update Progress
            progress += (Math.random() * 2);
            if (progress > 100) progress = 100;
            cb.onProgress(Math.floor(progress));

            // 3. Trigger Tool Calls (randomly)
            if (Math.random() > 0.92) {
                const toolTemplate = MOCK_TOOLS[Math.floor(Math.random() * MOCK_TOOLS.length)];
                const toolId = Math.random().toString(36).substr(2, 9);

                // Create pending tool
                cb.onToolCall({
                    id: toolId,
                    tool: toolTemplate.tool,
                    args: toolTemplate.args,
                    status: "running",
                    timestamp: new Date().toLocaleTimeString()
                });

                // Finish tool after delay
                setTimeout(() => {
                    cb.onToolUpdate(toolId, { status: "completed", result: "Done" });
                }, 1500);
            }

            // 4. Trigger Diffs (rarely)
            if (Math.random() > 0.96) {
                const diff = MOCK_DIFFS[Math.floor(Math.random() * MOCK_DIFFS.length)];
                cb.onDiff(diff);
            }

            // Advance simulated thought process
            if (Math.random() > 0.8) step++;

            // End condition
            if (step >= MOCK_RESPONSES.length + 5 || progress >= 100) {
                clearInterval(interval);
                cb.onStatus("COMPLETED");
                cb.onProgress(100);
                cb.onComplete();
            }

        }, 150); // Fast tick
    }, 1000); // Initial think time
}
