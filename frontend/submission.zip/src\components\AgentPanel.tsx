"use client"

import { useState } from "react"
import { AgentState } from "@/lib/types"
import { FileDiffViewer } from "./FileDiffViewer"
import { ArrowLeft } from "lucide-react"

interface AgentPanelProps {
    agent: AgentState
}

export function AgentPanel({ agent }: AgentPanelProps) {
    const [view, setView] = useState<"output" | "files">("output")
    const [selectedFile, setSelectedFile] = useState<string | null>(null)

    const handleFileClick = (file: string) => {
        setSelectedFile(file)
    }

    // Filter diffs for the selected file
    const activeDiffs = agent.diffs?.filter(d => d.path === selectedFile) || []

    return (
        <div className="flex-1 flex flex-col bg-background h-full overflow-hidden transition-all duration-300">
            {/* Header */}
            <div className="border-b border-border px-6 py-4 bg-background">
                <div className="flex items-start justify-between">
                    <div>
                        <div className="text-xl font-medium tracking-wide mb-1 font-mono">{agent.name}</div>
                        <div className="text-xs text-muted-foreground tracking-wide font-mono">{agent.task}</div>
                    </div>

                    <div className="flex items-center gap-3 font-mono">
                        <div className="text-[10px] text-muted-foreground">PROGRESS: {Math.round(agent.progress)}%</div>
                        <div
                            className={`text-xs px-2 py-1 border ${agent.status === "STREAMING"
                                ? "border-foreground animate-pulse"
                                : agent.status === "IDLE"
                                    ? "border-muted-foreground"
                                    : "border-destructive"
                                }`}
                        >
                            {agent.status}
                        </div>
                        <button className="px-3 py-1 border border-border hover:bg-destructive hover:text-destructive-foreground transition-colors text-xs">
                            STOP
                        </button>
                    </div>
                </div>
            </div>

            {/* Tabs */}
            <div className="border-b border-border flex font-mono">
                <button
                    onClick={() => { setView("output"); setSelectedFile(null); }}
                    className={`px-6 py-3 text-xs font-medium tracking-wider border-r border-border transition-colors ${view === "output" ? "bg-foreground text-background" : "hover:bg-muted"
                        }`}
                >
                    OUTPUT
                </button>
                <button
                    onClick={() => { setView("files"); setSelectedFile(null); }}
                    className={`px-6 py-3 text-xs font-medium tracking-wider border-r border-border transition-colors ${view === "files" ? "bg-foreground text-background" : "hover:bg-muted"
                        }`}
                >
                    FILES ({agent.files.length})
                </button>
                <button className="px-6 py-3 text-xs font-medium tracking-wider text-muted-foreground hover:bg-muted transition-colors">
                    LOGS
                </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-hidden font-mono bg-black/5 relative">
                {view === "output" && (
                    <div className="h-full overflow-y-auto p-6">
                        <pre className="text-xs leading-relaxed whitespace-pre-wrap text-muted-foreground">
                            <span className="text-primary mr-2">➜</span>
                            {agent.output}
                            {agent.status === "STREAMING" && <span className="animate-pulse inline-block w-2 h-4 bg-primary ml-1 align-middle opacity-50" />}
                        </pre>
                    </div>
                )}

                {view === "files" && (
                    <div className="h-full flex flex-col">
                        {selectedFile ? (
                            <div className="flex-1 flex flex-col">
                                <div className="px-4 py-2 border-b border-border bg-muted/10 flex items-center gap-2">
                                    <button onClick={() => setSelectedFile(null)} className="p-1 hover:bg-muted rounded">
                                        <ArrowLeft className="w-4 h-4" />
                                    </button>
                                    <span className="text-xs font-bold">{selectedFile}</span>
                                </div>
                                <div className="flex-1 overflow-y-auto">
                                    <FileDiffViewer diffs={activeDiffs} />
                                </div>
                            </div>
                        ) : (
                            <div className="h-full overflow-y-auto">
                                {agent.files.map((file, index) => (
                                    <div
                                        key={index}
                                        onClick={() => handleFileClick(file)}
                                        className="border-b border-border px-6 py-4 hover:bg-muted transition-colors cursor-pointer group"
                                    >
                                        <div className="flex items-center justify-between">
                                            <div className="text-xs font-mono group-hover:text-primary transition-colors">{file}</div>
                                            <div className="text-[10px] text-muted-foreground group-hover:text-primary">MODIFIED ➜</div>
                                        </div>
                                    </div>
                                ))}
                                {agent.files.length === 0 && (
                                    <div className="p-10 text-center text-xs text-muted-foreground opacity-50">NO FILES MODIFIED</div>
                                )}
                            </div>
                        )}
                    </div>
                )}
            </div>

            {/* Footer Actions */}
            <div className="border-t border-border px-6 py-4 flex items-center justify-between bg-background font-mono">
                <div className="flex items-center gap-3">
                    <button
                        onClick={() => alert("Changes Approved. Deploying to staging...")}
                        className="px-4 py-2 border border-border hover:bg-primary hover:text-primary-foreground transition-colors text-xs font-medium tracking-wide"
                    >
                        APPROVE
                    </button>
                    <button
                        onClick={() => alert("Changes Rejected. Rolling back...")}
                        className="px-4 py-2 border border-border hover:bg-muted transition-colors text-xs font-medium tracking-wide"
                    >
                        REJECT
                    </button>
                    <button
                        onClick={() => alert("Entering Modification Mode...")}
                        className="px-4 py-2 border border-border hover:bg-muted transition-colors text-xs font-medium tracking-wide"
                    >
                        MODIFY
                    </button>
                </div>

                <button
                    onClick={() => alert("Log Exported to ./logs/agent-session.log")}
                    className="text-xs text-muted-foreground hover:text-foreground transition-colors"
                >
                    EXPORT_LOG →
                </button>
            </div>
        </div>
    )
}
